#include<string>
#include<vector>
#include<map>
#include<fstream>
#include<random>
#include<memory>
#include<iostream>
#include<sstream>
#include<algorithm>

#include"helper.h"

extern const unsigned num_countries = 195;
extern const std::vector<std::string> countries = {
"Afghanistan", "Albania", "Algeria", "Andorra", "Angola",
"Antigua and Barbuda", "Argentina", "Armenia", "Australia",
"Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh",
"Barbados", "Belarus", "Belgium", "Belize", "Benin","Bhutan",
"Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil",
"Brunei", "Bulgaria", "Burkina Faso", "Burundi","Côte d'Ivoire",
"Cabo Verde", "Cambodia", "Cameroon", "Canada", "Central African Republic",
"Chad", "Chile", "China","Colombia", "Comoros", "Congo",
"Costa Rica", "Croatia", "Cuba", "Cyprus", "Czechia",
"Democratic Republic of the Congo", "Denmark", "Djibouti",
"Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador",
"Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", "Ethiopia",
"Fiji", "Finland", "France", "Gabon", "Gambia", "Georgia","Germany",
"Ghana", "Greece", "Grenada", "Guatemala", "Guinea", "Guinea-Bissau",
"Guyana", "Haiti", "Holy See","Honduras", "Hungary", "Iceland", "India",
"Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica",
"Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Kuwait",
"Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho","Liberia",
"Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Madagascar",
"Malawi", "Malaysia", "Maldives", "Mali","Malta", "Marshall Islands",
"Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco",
"Mongolia","Montenegro", "Morocco", "Mozambique", "Myanmar", "Namibia",
"Nauru", "Nepal", "Netherlands", "New Zealand","Nicaragua", "Niger",
"Nigeria", "North Korea", "North Macedonia", "Norway", "Oman",
"Pakistan", "Palau", "Palestine State", "Panama", "Papua New Guinea",
"Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar",
"Romania","Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia",
"Saint Vincent and the Grenadines", "Samoa", "San Marino",
"Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia",
"Seychelles", "Sierra Leone", "Singapore", "Slovakia","Slovenia",
"Solomon Islands", "Somalia", "South Africa", "South Korea",
"South Sudan", "Spain", "Sri Lanka", "Sudan","Suriname",
"Sweden", "Switzerland", "Syria", "Tajikistan", "Tanzania",
"Thailand", "Timor-Leste", "Togo", "Tonga","Trinidad and Tobago",
"Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine",
"United Arab Emirates","United Kingdom", "United States of America",
"Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Yemen","Zambia",
"Zimbabwe"
};

void write_to_csv (std::vector<unsigned int>& global_cases,
                   std::string filename)
{
    /*
    * Generates a csv (comma separated values) of (country, cases).
    * This creates a file "global_cases.csv" by default in the
    * current folder. We use the <fstream> header for writing to the
    * file.
    */

   // open file stream for output
   std::ofstream csv_file(filename);

   // csv column headers
   csv_file << "country,cases\n";

   for( size_t i = 0; i < global_cases.size(); i++ ){

       /* We can write to a file in the same way as we write to std::cout.
        * This is because both are implemented as "streams"
        *
        * We do not need to pass the "countries" array to our
        * "function" since it is static. Avoid doing this,
        * we will learn better ways to organize our code later.
        */
       csv_file << countries[i] << "," << global_cases[i] << "\n";
   }

   csv_file.close();
}

void populate_vector( std::vector<unsigned int>& global_cases)
{
    /*
    * Populate a vector with pseudo-random data generated using the mersenne
    * twister engine from <random>. The seed is set to 0 so that everyone
    * gets the same sequence of 'random' numbers.
    */

    auto seed = 0;
    auto min = 0;
    auto max = 10000;

    // mt19337: a pseudo random generator using the mersenne
    // twister engine ( from <random> )
    // The value of gen will be updated every time we access it.
    std::mt19937 gen(seed);
    // uniform_int_distribution: use the mersenne twister
    // engine to generate a uniform random distribution over (min, max)
    std::uniform_int_distribution<unsigned int> unif_distrib(min, max);

    /* 3. populate vector global_cases with random data
    * You can generate samples from the uniform distribution above like so:
    * unif_distrib(gen)
    */

   // 3. solution
   for( auto& elem : global_cases){
       elem = unif_distrib(gen);
   }
}

std::ostream& operator<<(std::ostream& os, std::vector<unsigned> vec)
{
    for(const auto& elem : vec)
    {
        os << elem << " " ;
    }
    os << '\n';
    return os;
}

std::ostream& operator<<(std::ostream& os, std::vector<double> vec)
{
    for(const auto& elem : vec)
    {
        os << elem << " " ;
    }
    os << '\n';
    return os;
}

std::unique_ptr<DataFrame> read_from_csv( std::string filename)
{
    /*
    ** Read from a csv and populate a DataFrame.
    ** Return a unique_ptr to this DataFrame.
    */

    std::ifstream database(filename);

    std::unique_ptr<DataFrame> data = std::make_unique<DataFrame>();

    // parse data into these vars
    unsigned day_of_month;
    unsigned cases;
    std::string region;
    unsigned population;
    std::string curr_region = "";

    std::string line;
    // throw away first line: contains csv header
    std::getline(database, line);

    // keep track of region number
    // region names are repeated in csv
    auto region_num = -1;

    // while lines in csv
    while( std::getline(database, line) )
    {
        std::replace(line.begin(), line.end(), ',', ' ');
        std::stringstream line_stream(line);
        // stringstream breaks on spaces
        line_stream >> day_of_month >> cases >> region >> population;

        if( curr_region != region ){
            // -> operator: dereference pointer + access member / field
            // e.g. imagine: DataFrame* data;
            // then to access the cases field
            // we need: (*data).cases == data->cases
            curr_region = region;
            data->regions.push_back(region);
            data->population.push_back(population);
            data->cases.push_back(std::vector<unsigned>{});

            ++region_num;
        }

        data->cases[region_num].push_back(cases);
    }
    return data;
}

std::map<std::string, std::vector<double>> normalize_per_capita(std::unique_ptr<DataFrame>& data_frame)
{
    /*
    ** Normalize cases in data_frame by population i.e.
    ** compute cases per 100,000 people in each country.
    ** Returns a std::map<std::string, std::vector<double>>
     */

    auto& cases = data_frame->cases;
    auto& regions = data_frame-> regions;
    auto& population = data_frame->population;

    // map: name of region to a vector containing cases
    std::map<std::string, std::vector<double>> cases_normalized;

    for(size_t region_num = 0; region_num < regions.size(); ++region_num)
    {
        auto reg_name = regions[region_num];
        auto reg_pop = population[region_num];

        // for each region, go over its cases
        for(size_t day_num = 0; day_num < cases[region_num].size(); ++day_num)
        {
            auto daily_normalized = (100'000.0 * cases[region_num][day_num])/ reg_pop;
            // populate map
            cases_normalized[reg_name].push_back(daily_normalized);
        }
    }
    return cases_normalized;
}
